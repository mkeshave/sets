﻿
create table Vidya.UniversityTraineeDetails(
Id int primary key,
ModuleName varchar(50) not null,
BatchName varchar(25) not null,
Comments varchar(1000) null
);



create proc Vidya.USP_UniversityTraineeInsert
@id int,
@mname varchar(50),
@bname varchar(25),
@cname varchar(1000)
as
	begin
		insert into Vidya.UniversityTraineeDetails values(@id,@mname,@bname,@cname)
	end

select * from Vidya.UniversityTraineeDetails