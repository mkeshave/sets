﻿

//------------------------------------------------------------------------------
// <header>
//     File Name: UniversityTraineePerfBL.cs
//     Creation Date: 14/12/2018        
//     Author: Vidya Honde.
//     
// </header>
//------------------------------------------------------------------------------




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversitySystem.DataAccessLayer;
using UniversitySystem.Entity;
using UniversitySystem.ExceptionClass;

namespace UniversitySystem.BussinessLayer
{
    /// <summary>
    /// Bussiness logic for UniversityTrainee Entity.
    /// </summary>
    public class UniversityTraineePerfBL
    {
        //This method checks whether user entered correct data or not.
        private static bool ValidateTrainee(UniversityTraineePerformance trainee)
        {
            StringBuilder stringBuilder = new StringBuilder();

            bool validTrainee = true;

            if (trainee.EmpId < 0)
            {
                validTrainee = false;
                stringBuilder.Append(Environment.NewLine + "Enter valid EmpID");
            }
            if (trainee.ModuleName == string.Empty)
            {
                validTrainee = false;
                stringBuilder.Append(Environment.NewLine + "Module Name Required");
            }
            if (trainee.BatchName == string.Empty)
            {
                validTrainee = false;
                stringBuilder.Append(Environment.NewLine + "Enter Batch Name");
            }

            if (trainee.Comments.Length < 0)
            {
                validTrainee = false;
                stringBuilder.Append(Environment.NewLine + "Enter Comments");
            }

            if (validTrainee == false)
            {
                throw new UniversitySysExceptionClass(stringBuilder.ToString());
            }

            return validTrainee;
        }


        public static bool AddTraineeBL(UniversityTraineePerformance trainee)
        {
            bool traineeAdded = false;

            try
            {
                if (ValidateTrainee(trainee))
                {
                    UniversityTraineePerfDAL traineeDAL = new UniversityTraineePerfDAL();
                    traineeAdded = traineeDAL.InsertDAL(trainee);
                }
            }
            catch (UniversitySysExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return traineeAdded;
        }
    }
}
