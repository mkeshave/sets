﻿//------------------------------------------------------------------------------
// <header>
//     File Name: MainWindow.xaml.cs
//     Creation Date: 14/12/2018        
//     Author: Vidya Honde.
//     
// </header>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UniversitySystem.ExceptionClass;
using UniversitySystem.Entity;
using UniversitySystem.BussinessLayer;

namespace UniversitySystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        UniversityTraineePerformance trainee = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        //this method validate text filed whether it is empty or not and if empty then prompt an appropriate message to user.
        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            if (txtEmpId.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Emp ID Required");
            }
            if (txtModuleName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            if (txtBatchName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Batch name Required");
            }
            if (txtComments.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Comments Required");
            }

            if (isValid == false)
            {
                throw new UniversitySysExceptionClass(sb.ToString());
            }

            return isValid;
        }

        //this methgod collects data from user and pass it to the bussiness layers method.
        private void BtnAddEntry_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    trainee = new UniversityTraineePerformance();
                    trainee.EmpId = Convert.ToInt32(txtEmpId.Text);
                    trainee.ModuleName = txtModuleName.Text;
                    trainee.BatchName = txtBatchName.Text;
                    trainee.Comments = txtComments.Text;
                    //trainee.Comments = Save();
                    //MessageBox.Show(Save());
                    status = UniversityTraineePerfBL.AddTraineeBL(trainee);
                    
                }
                if (status == true)
                    MessageBox.Show("Inserted");

            }
            catch (UniversitySysExceptionClass ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        ////this method returns a string by removing a space and new line from it.
        //protected string Save()
        //{
        //    string replaceValue = txtComments.Text.Replace(Environment.NewLine, "$");
        //    string cmnts = "";
        //    string[] values = replaceValue.Split('$');
        //    foreach (string item in values)
        //    {
        //        cmnts+=item.Trim();
        //    }
        //    return cmnts;
        //}
    }
}
