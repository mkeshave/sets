﻿//------------------------------------------------------------------------------
// <header>
//     File Name: UniversityTraineePerfDAL.cs
//     Creation Date: 14/12/2018        
//     Author: Vidya Honde.
//     
// </header>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using UniversitySystem.Entity;
using UniversitySystem.ExceptionClass;

namespace UniversitySystem.DataAccessLayer
{
    //this class contains a logic related to database connectivity.
    public class UniversityTraineePerfDAL
    {
        //declare references of SqlConnection, SqlCommand and SqlDataReader.
        SqlConnection conn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        //default constructor. it instantiate a SqlConnection object.
        public UniversityTraineePerfDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }

        /// <summary>
        /// Data Access Layer logic for UniversityTrainee Entity.
        /// this method insert a data into a database.
        /// </summary>
        public bool InsertDAL(UniversityTraineePerformance traineePerf)
        {
            bool traineeAdded = false;
            try
            {
                cmd = new SqlCommand("Vidya.USP_UniversityTraineeInsert", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", traineePerf.EmpId);
                cmd.Parameters.AddWithValue("@mname", traineePerf.ModuleName);
                cmd.Parameters.AddWithValue("@bname", traineePerf.BatchName);
                cmd.Parameters.AddWithValue("@cname", traineePerf.Comments);
                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    traineeAdded = true;
            }
            catch (Exception ex)
            {
                throw new UniversitySysExceptionClass(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return traineeAdded;
        }

    }
}
