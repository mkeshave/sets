﻿//------------------------------------------------------------------------------
// <header>
//     File Name: UniversityTraineePerformance.cs
//     Creation Date: 14/12/2018        
//     Author: Vidya Honde.
//     
// </header>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversitySystem.Entity
{
    //class defination. this is a entity class contents properties of entity.
    public class UniversityTraineePerformance
    {
        public int EmpId { get; set; }
        public string ModuleName { get; set; }
        public string BatchName { get; set; }
        public string Comments { get; set; }
    }
}
