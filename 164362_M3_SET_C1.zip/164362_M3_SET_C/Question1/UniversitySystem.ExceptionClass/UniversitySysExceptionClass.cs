﻿//------------------------------------------------------------------------------
// <header>
//     File Name: UniversitySysExceptionClass.cs
//     Creation Date: 14/12/2018        
//     Author: Vidya Honde.
//     
// </header>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversitySystem.ExceptionClass
{
    //Exception class
    public class UniversitySysExceptionClass : ApplicationException
    {
        //Default constructor
        public UniversitySysExceptionClass() : base()
        { }

        /*Parameterized constructor.
         * parameter type: String
         */
        public UniversitySysExceptionClass(string message) : base(message)
        { }

        /*Parameterized constructor.
         * parameter type: String , Exception class object.
         */
        public UniversitySysExceptionClass(string message, Exception exception) : base(message, exception)
        { }
    }
}
