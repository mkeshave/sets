﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes; 

namespace Question2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //create referance of Training_24Oct18_PuneEntities class.
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();

            //initialize a instance of class Training_24Oct18_PuneEntities.
            dbContext = new Training_24Oct18_PuneEntities();
        }

        //method to show details of module.
        private void ShowModuleDetails()
        {
            //retive result from database using datacontext.
            List<UniversityTraineeDetail> traineeDetailsList = dbContext.UniversityTraineeDetails.ToList();

            //linq query to retrive records from database having batch name is ".Net Batch".
            var res = traineeDetailsList.Where(s => s.BatchName ==".Net Batch").Select (s=> new {s.Id,s.ModuleName,s.BatchName,s.Comments });

            //assign result to datagrid.
            dgtrainee.ItemsSource = res;
           
        }

        //this method calls when window loads.
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //show data at the time of window load.
            ShowModuleDetails();
        }
    }

}
