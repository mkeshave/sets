﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Module.Enitities;
using Module.Exceptions;
using Module.DataAccess;
using Module.BusinessLayer;

namespace Module.Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       //checking for validation
        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;

            if (empid.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Module Name Required");
            }
            if (empname.Text == string.Empty) 
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }
            if (batchnm.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }

            if (Comments.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }



            return isValid;
        }

        //inserting the values intot the database
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                   ModuleEntities p = new ModuleEntities()
                    {

                        empId = Convert.ToInt32(empid.Text),
                        ModuleName =empname.Text,
                       BatchName = batchnm.Text,
                       comments = Comments.Text

                    };
                    status = ModuleBL.AddProdBL(p);

                }
                else
                {
                    MessageBox.Show("Enter Data");
                }
                if (status == true)
                    MessageBox.Show("Inserted");
             
            }
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }






    }


}
