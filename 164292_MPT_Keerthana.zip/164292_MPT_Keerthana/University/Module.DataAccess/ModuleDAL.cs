﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module.Enitities;
using Module.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace Module.DataAccess
{
    public class ModuleDAL
    {        /* setting sql connection*/
            SqlConnection cn = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
        /* connecting with database*/
            public ModuleDAL()
            {
                cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
            }

         //inserting the values
            public bool Insert(ModuleEntities product)
            {
                bool prodAdded = false;// setting the value as false 
                try
                {
                  
                    cmd = new SqlCommand("Keerthana.USP_InsertModule2", cn);// calling for stored procedure
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empId", product.empId);//inserting the id
               
                    cmd.Parameters.AddWithValue("@Module", product.ModuleName);//inserting the module num
                cmd.Parameters.AddWithValue("@batch", product.BatchName);//inserting the  batch name
                cmd.Parameters.AddWithValue("@comments", product.comments);//inserting the comments
                cn.Open();
                    int row = cmd.ExecuteNonQuery();
                    if (row > 0)// cheching for row inserted or not
                        prodAdded = true;

                }
                catch (Exception ex1)
                {
                    throw ex1;
                }
                finally
                {
                    //to close connection
                    if (cn.State == System.Data.ConnectionState.Open)
                        cn.Close();

                }
                return prodAdded;

            }

           
        }
    }
