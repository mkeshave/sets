﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module.Exceptions
{
    public class ModuleException: ApplicationException
    {
        public ModuleException() : base()
        {

        }

        public ModuleException(string message) : base(message)
        {

        }

        public ModuleException(string message, Exception objEx) : base(message, objEx)
        {

        }

    }
}
