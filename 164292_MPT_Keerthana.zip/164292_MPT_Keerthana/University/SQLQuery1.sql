﻿CREATE TABLE [Keerthana].[Module2] (
    [Id]       INT     NOT NULL,
    [ModuleName] VARCHAR (20) NULL,
    [BatchName]    Varchar (18) NULL,
    [Comments]  Varchar (50)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


Create Proc Keerthana.USP_InsertModule2
@empId int ,
@Module varchar(20),
@batch varchar(18),
@comments varchar(50)
as
Insert into Keerthana.Module2 values(@empId, @Module,@batch,@comments);


select * from Keerthana.Module2;