﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module.Enitities
{
    public class ModuleEntities
    {
        public int empId { get; set; }
        public string ModuleName { get; set; }
        public string BatchName { get; set; }
        public string comments { get; set; }
    }
}
