﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module.Enitities;
using Module.DataAccess;
using Module.Exceptions;

namespace Module.BusinessLayer
{
    public class ModuleBL
    {
           //validating the entered values 
            private static bool ValidateProd(ModuleEntities product)
            {
                StringBuilder sb = new StringBuilder();

                bool validProd = true;

            if (product.empId.ToString() == string.Empty)//validation for id
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid EmpID");
                }

                if (product.ModuleName.ToString().Length < 0)//validation for module num
                {
                    validProd = false;
                    sb.Append(Environment.NewLine + "Enter valid Date");
                }

                if (product.BatchName.ToString().Length < 0)//validation for batch name
                {
                    validProd = false;
                    sb.Append(Environment.NewLine + "Enter valid Date");
                }


            if (product.comments.ToString().Length < 0)//validation for comments
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }


            return validProd;
            }

           

            public static bool AddProdBL(ModuleEntities product)
            {
                bool prodAdded = false;

                try
                {
                    if (ValidateProd(product))
                    {
                        ModuleDAL prodDAL = new ModuleDAL();//call for module dataaccesslayer
                        prodAdded = prodDAL.Insert(product);
                    }
                }

                catch (Exception ex)
                {
                    throw ex;
                }

                return prodAdded;
            }

           

           
    }
}