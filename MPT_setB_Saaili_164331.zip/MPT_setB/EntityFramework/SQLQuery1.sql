﻿create schema saaili345;

create table saaili345.Customer
(
[Id] INT identity(1,1) NOT NULL PRIMARY KEY,
[Name] varchar (10) null,
[Address] varchar (20) null,
[City] varchar (10) null,
[ContactNo] varchar (10) null
)

insert into saaili345.Customer values('saaili' , 'Mumbai', 'panvel', 8818885283)
insert into saaili345.Customer values('sakshi' , 'Mumbai', 'panvel', 8818885483)
insert into saaili345.Customer values('chandni' , 'Mumbai', 'panvel', 8818885583)
insert into saaili345.Customer values('minu' , 'Mumbai', 'panvel', 8818885683)
insert into saaili345.Customer values('minu' , 'Pune', 'panvel', 8818885683)
select * from saaili345.Customer;