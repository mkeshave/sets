﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFramework
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }
        public void PopulateUI()
        {
            List<Customer> prods = dbContext.Customers.ToList();
            //display only customer who reside in mumbai
            var res = from p in prods where p.City.Equals("Mumbai") select p;
            
            dgProducts.ItemsSource = res;
            MessageBox.Show("Data Display");

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        //Inserting data

        private void InsertBtn_Click(object sender, RoutedEventArgs e)          
        {
            Customer prod = new Customer();
            prod.Name = Name.Text;
            prod.Address = Address.Text;
            //prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.City =City.Text;
            prod.ContactNo = ContactNo.Text;
            dbContext.Customers.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Data Inserted"); 
            //To show the records
            PopulateUI();                                   
        }
    }
}
