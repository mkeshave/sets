﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CustomerDataAccessLayer;
using CustomerBusinessLayer;
using CustomerException;
using CustomerEntity;

namespace CustomerFoodDelivery
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CustomerBL bl = new CustomerBL();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //PopulateUI();
        }

        //public void PopulateUI()
        //{
        //    IEnumerable<Customer> cust = bl.SelectAll();
        //    dgProducts.ItemsSource = cust;
            
        //}
        public bool IsInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (CustomerName.Text == null | CustomerName.Text == string.Empty | CustomerName.Text.Length < 1)
            {
                sb.Append("\nCustomer-Name is Mandatory!");
                isValid = false;
            }
            if (CustomerAddress.Text == null | CustomerAddress.Text == string.Empty | CustomerAddress.Text.Length < 1)
            {
                sb.Append("\nCustomer-Name is Mandatory!");
                isValid = false;
            }
            if (CustomerLandmark.Text == null | CustomerLandmark.Text == string.Empty | CustomerLandmark.Text.Length < 1)
            {
                sb.Append("\nLandmark is Mandatory!");
                isValid = false;
            }
            if (CustomerPincode.Text == null | CustomerPincode.Text == string.Empty | CustomerPincode.Text.Length < 1)
            {
                sb.Append("\nPincode is Mandatory!");
                isValid = false;
            }
            if (ContactNumber.Text == null | ContactNumber.Text == string.Empty | ContactNumber.Text.Length < 1)
            {
                sb.Append("\nContactNo is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Customer_Exception(sb.ToString());
            }

            return isValid;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {
                    Customer c = new Customer
                    {
                        Name = CustomerName.Text,
                        Address = CustomerAddress.Text,
                        Landmark = CustomerLandmark.Text,
                        //City = Convert.ToDateTime(ExpDate.Text)
                        Pincode = Convert.ToInt32(CustomerPincode.Text),
                        ContactNo = ContactNumber.Text,
                    };

                    bl.Insert(c);
                    MessageBox.Show("Data Inserted");
                    //PopulateUI();
                }
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }
    }
}

