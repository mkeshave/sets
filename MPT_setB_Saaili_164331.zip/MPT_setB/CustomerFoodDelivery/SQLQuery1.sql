﻿create schema saaili123;

Create table saaili123.Customer
(
[Id] INT identity(1,1) NOT NULL PRIMARY KEY,
[CustomerName] varchar (20) null,
[CustomerAddress] varchar (30) null,
[CustomerLandmark] varchar (20) null,
[Pincode] varchar (8) null,
[ContactNumbar] varchar (10) null
)

insert into saaili123.Customer values('sameer', 'mahananda nagar', 'Bhartiya school', 456010, 7566334860)

select* from  saaili123.Customer;

create proc saaili123.Customer_InsertCustomer
@custName varchar (20),
@address varchar (30),
@landmark varchar (20),
@pincode varchar (8),
@contactno varchar (10)
as
insert into saaili123.Customer values(@custName, @address, @landmark, @pincode, @contactno)