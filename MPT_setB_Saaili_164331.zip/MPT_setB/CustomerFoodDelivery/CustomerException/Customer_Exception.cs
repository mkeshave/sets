﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CustomerException
{
    public class Customer_Exception: Exception                                     //Exception Class
    {
        public Customer_Exception()
        {
        }

        public Customer_Exception(string message) : base(message)
        {
        }

        public Customer_Exception(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected Customer_Exception(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
