﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using CustomerEntity;
using CustomerException;

namespace CustomerDataAccessLayer
{
    public class CustomerDAL
    {
        SqlConnection cn = null;                                       //Establishing connection
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public CustomerDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }



        public void Insert(Customer customer)                                                   //Get values from user
        {
            try
            {
                cmd = new SqlCommand("saaili123.Customer_InsertCustomer", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@custName", customer.Name);
                cmd.Parameters.AddWithValue("@address", customer.Address);
                cmd.Parameters.AddWithValue("@landmark", customer.Landmark);
                //cmd.Parameters.AddWithValue("@city", customer.City);
                cmd.Parameters.AddWithValue("@pincode", customer.Pincode);
                cmd.Parameters.AddWithValue("@contactno", customer.ContactNo);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
        public IEnumerable<Customer> SelectAll()                                                       //To dosplay the user records
        {
            List<Customer> customers = new List<Customer>();
            try
            {
                cmd = new SqlCommand("select * from  saaili123.Customer", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Customer c = new Customer();
                        c.CustomerId = Convert.ToInt32(dr[0]);
                        c.Name = dr[1].ToString();
                        c.Address = dr[2].ToString();
                        c.Landmark = dr[3].ToString();
                        //c.City = dr[3].ToString();
                        c.Pincode = Convert.ToInt32(dr[3]);
                        c.ContactNo = dr[3].ToString();
                        customers.Add(c);
                    }
                }
                dr.Close();
            }
            catch (Exception e1)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return customers;
        }
    }
}
