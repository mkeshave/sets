﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerDataAccessLayer;
using CustomerEntity;

namespace CustomerBusinessLayer
{
    public class CustomerBL
    {
        CustomerDAL dal = new CustomerDAL();                    //Object of BL

        List<Customer> cust = new List<Customer>();

        public IEnumerable<Customer> SelectAll()
        {
            cust = dal.SelectAll().ToList();
            return cust;
        }

        public void Insert(Customer c)
        {
            dal.Insert(c);
        }


    }
}
